//
//  FFMpegCommand.h
//  ffmpegTest
//
//  Created by 9man on 16/1/22.
//  Copyright © 2016年 Nine Man. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FFMpegCommand : NSObject

+ (void)runCommandLine:(NSString *)commendLine finishCallBack:(void(^)(void))callBack;
+ (void)example;

@end
