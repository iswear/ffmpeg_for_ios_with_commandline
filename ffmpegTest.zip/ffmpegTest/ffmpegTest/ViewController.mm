//
//  ViewController.m
//  ffmpegTest
//
//  Created by 9man on 16/1/22.
//  Copyright © 2016年 Nine Man. All rights reserved.
//

#import "ViewController.h"
#import "FFMpegCommand.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    /*
     
     
    /Applications/Xcode.app/Contents/Developer/Platforms/iPhoneSimulator.platform/Developer/usr/bin:/Applications/Xcode.app/Contents/Developer/usr/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin"
    /Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/bin/clang++ -arch x86_64 -isysroot /Applications/Xcode.app/Contents/Developer/Platforms/iPhoneSimulator.platform/Developer/SDKs/iPhoneSimulator9.2.sdk -L/Users/songtao/Desktop/Derived\ Data/Build/Products/Debug-iphonesimulator -L/Users/songtao/Desktop/9MANPROJECTS/ffmpegTest/ffmpegTest/libs/lame -L/Users/songtao/Desktop/9MANPROJECTS/ffmpegTest/ffmpegTest/libs/FFmpeg-iOS/lib -L/Users/songtao/Desktop/9MANPROJECTS/ffmpegTest/ffmpegTest/libs/example -F/Users/songtao/Desktop/Derived\ Data/Build/Products/Debug-iphonesimulator -filelist /Users/songtao/Desktop/Derived\ Data/Build/Intermediates/ffmpegTest.build/Debug-iphonesimulator/ffmpegTest.build/Objects-normal/x86_64/ffmpegTest.LinkFileList -mios-simulator-version-min=6.0 -Xlinker -objc_abi_version -Xlinker 2 -stdlib=libc++ -fobjc-arc -fobjc-link-runtime -lavfilter -framework CoreMedia -framework AVFoundation -lavformat -lswresample -lavutil -lavdevice -liconv -lbz2 -lz -lswscale -lavcodec -lexample -lmp3lame -Xlinker -dependency_info -Xlinker /Users/songtao/Desktop/Derived\ Data/Build/Intermediates/ffmpegTest.build/Debug-iphonesimulator/ffmpegTest.build/Objects-normal/x86_64/ffmpegTest_dependency_info.dat -o /Users/songtao/Desktop/Derived\ Data/Build/Products/Debug-iphonesimulator/ffmpegTest.app/ffmpegTest
    
     
     */
    // Do any additional setup after loading the view, typically from a nib.
}

- (IBAction)buttonClick:(id)sender{
    [FFMpegCommand example];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
