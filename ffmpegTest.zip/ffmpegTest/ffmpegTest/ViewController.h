//
//  ViewController.h
//  ffmpegTest
//
//  Created by 9man on 16/1/22.
//  Copyright © 2016年 Nine Man. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak,nonatomic)IBOutlet UIButton    *button;

- (IBAction)buttonClick:(id)sender;

@end

