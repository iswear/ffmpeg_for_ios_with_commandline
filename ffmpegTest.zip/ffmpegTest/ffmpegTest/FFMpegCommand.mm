//
//  FFMpegCommand.m
//  ffmpegTest
//
//  Created by 9man on 16/1/22.
//  Copyright © 2016年 Nine Man. All rights reserved.
//


#import <Foundation/Foundation.h>
#import "FFMpegCommand.h"

#import "libavutil/ffmpeg.h"
 
@implementation FFMpegCommand

+ (void)runCommandLine:(NSString *)commendLine finishCallBack:(void(^)(void)) callBack{
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0), ^{
        if(commendLine != nil){
            NSArray *args = [commendLine componentsSeparatedByString:@" "];
            if(args != nil && args.count > 0){
                int argnum = 0;
                unsigned long argscount = args.count;
                NSMutableArray *runComLineParams = [[NSMutableArray alloc] init];
                for (unsigned long i = 0; i < argscount ; ++i) {
                    NSString *str = [args objectAtIndex:i];
                    if(str != nil && str.length > 0){
                        argnum ++;
                        [runComLineParams addObject:str];
                    }
                }
                char **args = (char **)malloc(argnum*sizeof(char *));
                for(int i=0;i<argnum;++i){
                    args[i] = (char *)[[runComLineParams objectAtIndex:i] cStringUsingEncoding:NSUTF8StringEncoding];
                }
                ffmpeg_main(argnum, args);
                free(args);
                if(callBack != nil){
                    callBack();
                }
            }
        }
    });
}


+ (void)example{
    NSString *home = NSHomeDirectory();
    NSLog(@"%@",home);
    NSString *inputFile = [NSString stringWithFormat:@"%@/Documents/test1.mp4",home];
    NSString *outputFile = [NSString stringWithFormat:@"%@/Documents/test2.mov",home];
    NSString *commandLine = [NSString stringWithFormat:@"ffmpeg -i %@ -strict -2 %@",inputFile,outputFile];
    [FFMpegCommand runCommandLine:commandLine finishCallBack:^{
        NSLog(@"%@",@"ffmpeg fun finished");
    }];
}

@end
